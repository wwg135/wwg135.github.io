#!/bin/bash

# Relaxin(RootHide 隐根) 版：jbroot 每次越狱随机命名，禁止硬编码 /var/jb。
# 本文件由 postinst 复制到真实 /var/mobile/tweak_tool/，供 Filza 直接点击运行。
# 若由越狱环境外的 shell 启动，先定位 jbroot 再切换进去执行。
if [ ! -e /rootfs ]; then
	for _d in /var/containers/Bundle/Application/.jbroot-* /private/var/containers/Bundle/Application/.jbroot-* /var/mobile/Containers/Bundle/Application/.jbroot-* /var/containers/Bundle/Application/*/.jbroot-*; do
		[ -x "${_d}/usr/local/bin/tweaktool" ] || continue
		exec "${_d}/bin/bash" "${_d}/usr/local/bin/tweaktool"
	done
	printf '%s\n' " 未检测到 Relaxin 越狱环境，请确认越狱已激活后重试"
	exit 1
fi
if [ -x /usr/local/bin/tweaktool ]; then
	exec /usr/local/bin/tweaktool
fi
exec tweaktool
